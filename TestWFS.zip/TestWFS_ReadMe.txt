Files included:

TestWFS_ReadMe.txt	This file
testwfs.map		The Mapserver map file
testwfstemplate.gml	The Mapserver template file
TestHydrants.mdb	The data file

Preparing the test case:

1. Set up a system DSN - Microsoft Access Driver (*.mdb -  Called TestHydrants pointing at TestHydrants.mdb.

2. Make sure that the epsg file in D:\mapserver\proj4 has the following line for OSGB 1936 / British National Grid:

<27700> +proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 +ellps=airy +datum=OSGB36 +units=m +no_defs  <>

3. Change location of epsg file in map file if required:

CONFIG "PROJ_LIB" "d:/mapserver/proj4"

4. Url for standard output:

http://localhost/cgi-bin/mapserv.exe?map=d:\mapserver\osmapfiles\testwfs.map&service=wfs&version=1.0.0&request=getfeature&typename=Hydrants&bbox=258481,665862,258607,665956

5. Url for templated output:

http://localhost/cgi-bin/mapserv.exe?map=d:\mapserver\osmapfiles\testwfs.map&service=wfs&version=1.0.0&request=getfeature&typename=Hydrants&bbox=258481,665862,258607,665956&outputformat=TestWFS

6. Working Mapserver Version:

MapServer version 6.0.3 (MS4W 3.0.6) OUTPUT=GIF OUTPUT=PNG OUTPUT=JPEG OUTPUT=KML SUPPORTS=PROJ SUPPORTS=AGG SUPPORTS=CAIRO SUPPORTS=FREETYPE SUPPORTS=ICONV SUPPORTS=FRIBIDI SUPPORTS=WMS_SERVER SUPPORTS=WMS_CLIENT SUPPORTS=WFS_SERVER SUPPORTS=WFS_CLIENT SUPPORTS=WCS_SERVER SUPPORTS=SOS_SERVER SUPPORTS=FASTCGI SUPPORTS=THREADS SUPPORTS=GEOS INPUT=JPEG INPUT=POSTGIS INPUT=OGR INPUT=GDAL INPUT=SHAPEFILE

7. Not working Mapserver Version:

MapServer version 6.2.0-beta1 OUTPUT=GIF OUTPUT=PNG OUTPUT=JPEG OUTPUT=KML SUPPORTS=PROJ SUPPORTS=GD SUPPORTS=AGG SUPPORTS=FREETYPE SUPPORTS=CAIRO SUPPORTS=ICONV SUPPORTS=FRIBIDI SUPPORTS=WMS_SERVER SUPPORTS=WMS_CLIENT SUPPORTS=WFS_SERVER S
UPPORTS=WFS_CLIENT SUPPORTS=WCS_SERVER SUPPORTS=SOS_SERVER SUPPORTS=FASTCGI SUPPORTS=THREADS SUPPORTS=GEOS INPUT=JPEG INPUT=POSTGIS INPUT=OGR INPUT=GDAL INPUT=SHAPEFILE

Thank you!