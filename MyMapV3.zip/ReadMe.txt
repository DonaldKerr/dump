Edit MyMap.htm and my.map and replace "D:\MyMap", "D:\\MyMap" and "d:/MyMap" with the loction that all these files are located.

Alter "http://localhost/cgi-bin/mapserv.exe" in MyMap.htm to whatever is appropriate for your setup.